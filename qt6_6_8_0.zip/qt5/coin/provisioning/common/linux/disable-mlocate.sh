#!/usr/bin/env bash

sudo chmod -x /etc/cron.daily/mlocate*
