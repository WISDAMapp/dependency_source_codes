## Qt contribution guidelines

We welcome contributions to Qt!

Note that all contributions to the Qt project are exclusively handled through the [Gerrit code review system](https://codereview.qt-project.org).

Read the
[Qt Contribution Guidelines](https://wiki.qt.io/Qt_Contribution_Guidelines) to learn more.

