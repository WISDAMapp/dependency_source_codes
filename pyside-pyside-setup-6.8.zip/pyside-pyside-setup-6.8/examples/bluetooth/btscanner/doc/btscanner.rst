Bluetooth Scanner Example
=========================

An example showing how to locate Bluetooth devices.
