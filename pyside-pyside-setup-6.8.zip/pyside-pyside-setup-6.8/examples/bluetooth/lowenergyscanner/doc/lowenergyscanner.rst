Bluetooth Low Energy Scanner Example
====================================

.. tags:: Android

A Python application that demonstrates the analogous example in Qt
`Bluetooth Low Energy Scanner <https://doc.qt.io/qt-6/qtbluetooth-lowenergyscanner-example.html>`_

.. image:: lowenergyscanner.png
    :width: 400
    :alt: lowenergyscanner screenshot
