Analog Clock Window Example
===========================

The Analog Clock Window example shows how to draw the contents of
a custom window.

This example demonstrates how the transformation and scaling
features of QPainter can be used to make drawing easier.
