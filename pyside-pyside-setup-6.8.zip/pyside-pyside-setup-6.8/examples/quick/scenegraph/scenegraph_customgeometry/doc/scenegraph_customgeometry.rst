Scene Graph - Custom Geometry
=============================

The custom geometry example shows how to create a QQuickItem which uses the
scene graph API to build a custom geometry for the scene graph. It does this
by creating a BezierCurve item which is made part of the CustomGeometry module
and makes use of this in a QML file.
