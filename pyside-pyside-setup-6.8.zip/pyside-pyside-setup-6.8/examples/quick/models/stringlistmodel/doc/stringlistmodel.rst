String List Model Example
=========================

.. tags:: Android

A model may be a simple 'list',
which provides the contents of the list via the modelData role.

.. image:: stringlistmodel.png
   :width: 400
   :alt: String List Model Screenshot
