Modbus Client example
=====================

The example acts as Modbus client sending Modbus request via serial line
and TCP respectively. The shown dialog allows the definition of standard
requests and displays incoming responses.

The example must be used in conjunction with the Modbus server example
or another Modbus device which is either connected via TCP or Serial Port.
