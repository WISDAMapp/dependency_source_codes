Simple HTTP Server Example
==========================

A simplified version of the C++ example
`Simple HTTP Server Example <https://doc.qt.io/qt-6/qthttpserver-simple-example.html>`_
