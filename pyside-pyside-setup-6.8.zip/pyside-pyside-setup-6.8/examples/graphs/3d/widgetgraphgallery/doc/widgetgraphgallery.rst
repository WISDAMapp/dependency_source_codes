Widget Graph Gallery
====================


Widget Graph Gallery demonstrates all three graph types and some of their
special features. The graphs have their own tabs in the application.


.. image:: widgetgraphgallery.webp
   :width: 400
   :alt: Widget Screenshot
