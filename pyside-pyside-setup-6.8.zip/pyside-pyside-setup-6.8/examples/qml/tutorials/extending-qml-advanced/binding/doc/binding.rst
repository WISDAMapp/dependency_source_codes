Extending QML - Binding Example
===============================

This example builds on the :ref:`example_qml_tutorials_extending-qml-advanced_adding`,
the :ref:`example_qml_tutorials_extending-qml-advanced_advanced5-attached-properties`,
the :ref:`example_qml_tutorials_extending-qml-advanced_advanced3-default-properties`,
the :ref:`example_qml_tutorials_extending-qml-advanced_advanced2-inheritance-and-coercion`
the :ref:`example_qml_tutorials_extending-qml-advanced_properties`
and the :ref:`example_qml_tutorials_extending-qml-advanced_advanced6-property-value-source`.

Running the Example
-------------------

The ``main.py`` file in the example includes a simple shell application that
loads and runs the QML snippet shown below.
