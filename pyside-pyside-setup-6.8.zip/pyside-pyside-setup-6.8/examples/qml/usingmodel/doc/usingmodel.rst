Using Model Example
===================

.. tags:: Android

A Python application that demonstrates how to use a :ref:`QAbstractListModel`
with QML.

.. image:: usingmodel.png
   :width: 400
   :alt: Using Model Screenshot
