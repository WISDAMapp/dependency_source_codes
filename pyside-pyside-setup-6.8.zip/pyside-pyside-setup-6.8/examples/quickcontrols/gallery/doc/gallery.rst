Qt Quick Controls 2 - Gallery
=============================

.. tags:: Android

The gallery example is a simple application with a drawer menu that contains
all the Qt Quick Controls 2. Each menu item opens a page that shows the
graphical appearance of a control, allows you to interact with the control, and
explains in which circumstances it is handy to use this control.
