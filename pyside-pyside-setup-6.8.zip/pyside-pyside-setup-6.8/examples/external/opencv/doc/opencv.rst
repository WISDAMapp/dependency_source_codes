OpenCV Face Detection Example
=============================

A Python application that demonstrates how to use OpenCV
and a trained model to detect faces detected from a webcam.

.. image:: opencv.png
   :width: 400
   :alt: OpenCV Face Detection Screenshot
