Matplotlib Widget 3D Example
============================

A Python application that demonstrates how to combine matplotlib
with Qt Widget-based functionality.

.. image:: widget3d.png
   :width: 400
   :alt: Matplotlib Widget 3D Screenshot
