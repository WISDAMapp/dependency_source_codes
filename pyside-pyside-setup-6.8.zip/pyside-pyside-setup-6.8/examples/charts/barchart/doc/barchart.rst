Bar Chart Example
==================

The example shows how to create a Bar chart.

.. image:: barchart.png
   :width: 400
   :alt: Bar Chart Screenshot
