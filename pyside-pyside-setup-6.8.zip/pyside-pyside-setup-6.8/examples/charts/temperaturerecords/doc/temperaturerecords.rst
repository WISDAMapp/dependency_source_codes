Temperature Records Example
===========================

The example shows how to create a bar chart with negative bars.

For our example we use temperature data.

.. image:: temperaturerecords.png
   :width: 400
   :alt: Temperature Records Screenshot
