Line Chart Example
==================

The example shows how to create a simple line chart.

.. image:: linechart.png
   :width: 400
   :alt: Line Chart Screenshot
