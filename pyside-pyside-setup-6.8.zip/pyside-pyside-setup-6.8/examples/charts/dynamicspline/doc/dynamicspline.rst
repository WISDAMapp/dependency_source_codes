Dynamic Spline Example
======================

This example shows how to draw dynamic data.

You can check a simple animation of this example
`here <https://qt-wiki-uploads.s3.amazonaws.com/images/thumb/f/f8/Dynamicspline.gif/300px-Dynamicspline.gif>`_.

.. image:: dynamicspline1.png
   :width: 400
   :alt: Dynamic Spline Screenshot 1

.. image:: dynamicspline2.png
   :width: 400
   :alt: Dynamic Spline Screenshot 2
