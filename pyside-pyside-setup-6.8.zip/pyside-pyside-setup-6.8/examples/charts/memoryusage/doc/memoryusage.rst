Memory Usag Example
===================

This example shows a QPieChart with the current memory usage in your
computer.

.. image:: memoryusage.png
   :width: 400
   :alt: Memory Usage Screenshot
