# Chart themes

To generated the file `ui_themewidget.py`, the following
command need to be executed:

`pyside6-uic themewidget.ui -o ui_themewidget.py`

Also, if you modify the UI file, then you would need
to run the previous command again.
