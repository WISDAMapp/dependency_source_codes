Document Viewer Example
=======================

A Widgets application to display and print JSON, text, and PDF files.

Document Viewer demonstrates how to use a QMainWindow with static
and dynamic toolbars, menus, and actions.


.. image:: documentviewer.png
   :width: 90%
   :align: center
   :alt: Document Viewer Example
