MIME Type Browser Example
=========================

A Python application that demonstrates the analogous example in C++
`MIME Type Browser Example <https://doc.qt.io/qt-6/qtcore-mimetypes-mimetypebrowser-example.html>`_

.. image:: mimetypesbrowser.png
   :width: 400
   :alt: mimetypebrowser screenshot

