Audio Source Example
====================

.. tags:: Android

A Python application that demonstrates the analogous example in C++
`Audio Source Example <https://doc.qt.io/qt-6/qtmultimedia-audiosource-example.html>`_


.. image:: audiosource.png
   :width: 400
   :alt: audiosource example

