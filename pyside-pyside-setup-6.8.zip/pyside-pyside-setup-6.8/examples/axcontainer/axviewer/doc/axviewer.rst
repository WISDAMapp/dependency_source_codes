Ax Viewer Example
=================

A simple example to use QAxWidget and access all the
available components.

.. image:: axviewer.png
   :width: 400
   :alt: Ax Viewer Screenshot
